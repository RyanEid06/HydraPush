# Android architecture

`MainActivity` -> `HydraPushApp` Compose navigation -> screens/viewmodels -> single `TrackerRepository` + Settings DataStore -> Room entities/DAOs. Notifications, widget callbacks, and backup service call the **same repository**, not a parallel in-memory model.

Suggested module structure, one app module in V1:

```
app/src/main/java/com/hydrapush/tracker/
  MainActivity.kt
  ui/                 HydraPushApp, theme, components, screens, sheets
  domain/             snapshot completion math, streaks, stats, validations
  data/local/         Room DB/DAO/entities/migrations
  data/preferences/   DataStore
  data/repository/    TrackerRepository
  reminders/          schedule/channel/receivers
  widget/             Glance AppWidget & safe action handlers
  backup/             SAF export/import validator
```

Use `StateFlow`, lifecycle-aware state collection, no network requests. Mutations transactional and on IO. Day-boundary handling should work even if app stays open across midnight and after boot/timezone changes. Do not schedule extremely frequent alarms just to update UI.

When a phone notification action or widget tries to mutate a day, repository must calculate actual local today itself. Avoid external file access except user-initiated Storage Access Framework backup. No background INTERNET capability.

A staged implementation is expected. Keep one green build per feature cluster. `docs/IMPLEMENTATION_PHASES.md` gives detailed checkpoints.
