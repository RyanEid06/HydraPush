# Visual UI contract — approved screenshots (do not invent a new direction)

## Design reference hierarchy

1. `V1-Design/HydraPush Dashboard.png` — source of truth for dashboard.
2. `V1-Design/HydraPush Stats Dashboard Trio.png` — source of truth for 3 stats states.
3. `V1-Design/HydraPush Settings Dashboard.png` — source of truth for settings; insert **Active Habits** card naturally.
4. Individual `Stats*.png` crops are convenience reference, not independent alternate designs.

The images are mobile mockups in a phone frame. **Render UI components natively**, don't embed screenshot backgrounds, status bar, device bezel, or fixed text/data. Avoid crop-and-paste gradients/banners into giant raster backgrounds. Custom athlete header can be implemented with a small own/vector/asset if faithfully recreated, but must not cover text.

## Layout

- Scaffold with status/nav system insets; 3-item rounded bottom nav anchored above gesture system bar; selected tab aqua capsule.
- White mist background, rounded cards with subtle teal/lime surface tint and fine border/shadow, generous but efficient spacing, human-friendly dense information.
- Brand header HydraPush in dark green + teal, aqua water-drop logomark, translucent running figure sweeping upper right. On small devices simplify runner asset rather than clipping dashboard.
- Dashboard main cards are **side-by-side** on standard phone widths, Water turquoise and Push-ups vivid lime; smaller pair of optional habit cards below; streak and daily summary compact and legible.
- Stats retains common header and 7D/30D/90D/All segmented range selector; overview KPI cards, weekly bar chart, habit circular indicators, achievement row. On Water/Push-up tabs, replace overview with dedicated metrics/line or bars/consistency and records.
- Settings: groups Daily Goals; **Active Habits** (new); Reminders; Appearance; Data; About. Calm compact list rows and actionable controls, no big stock illustrations.
- Rounded corners 16–26dp for main cards; cards must not appear like bloated fixed-size screenshots.

## Accessibility & small phones

- Responsive at 360dp (and 320dp if possible), 1.3–1.5 font scale, keyboard open, notched and gesture-navigation devices.
- No text clipped under chart labels, bottom bar or header. Scroll screens vertically if necessary; fixed nav remains visible.
- All quick logging buttons at least 44–48dp height, with descriptive semantics and confirmation feedback.
- Stats chart has labels/values readable with a screen reader, plus optional textual data rows.
- Touch feedback subtle. Animation duration around 150–400ms; respect reduced motion settings.

## Illustration and color

Palette/spacing in `design/tokens.json` are design intent, not pixel-extracted constraints. Avoid neon orange or black-heavy 'gym bro' look from rejected concepts. Keep deep charcoal/dark green text legible, aqua/teal primary, lime push-up, soft orange-coral protein, sky-blue tertiary.

## Real data display

Every number shown in generated mockups is EXAMPLE data and must be replaced at runtime. Especially do not hardcode 'Wed Jan 29', '7 Day Streak', '24 Perfect Days', '2,300 ml', '86 reps', '90%' etc.
