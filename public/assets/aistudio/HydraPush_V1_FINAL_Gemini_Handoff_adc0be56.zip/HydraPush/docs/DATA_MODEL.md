# Persisted data schema / ownership contracts

> Treat this as an implementation contract. The scaffold Kotlin file `data/local/TrackerEntities.kt` contains seed declarations; Gemini should expand/migrate it as needed without destructive reset.

## Tables

**daily_snapshots**
- `day: String` ISO local date, PK
- `waterGoalMl: Int` >0, `pushUpGoalReps: Int` >0
- `creatineRequired: Boolean`, `proteinRequired: Boolean`
- `creatineDone: Boolean`, `proteinDone: Boolean`
- `requirementsRevisionId: Long?` to point at settings version
- `createdAtEpochMs`, `lockedAtEpochMs?` optional audit values
- Never overwrite records of days earlier than local today except deliberate complete backup restore.

**water_entries**
- `id: Long` auto PK; `day: String` indexed FK to daily_snapshots; `amountMl: Int` positive, `createdAtEpochMs: Long`. (When deletion/undo used, delete today's event.)

**push_up_sets**
- `id: Long` auto PK; `day: String` indexed FK; `reps: Int` positive; `createdAtEpochMs: Long`, `sequence: Int` if deterministic ordering required.

**configuration_revisions**
- `id: Long` auto PK, `effectiveLocalDay: String` indexed, `recordedAtEpochMs: Long`, plus water goal, push-up goal, creatine required, protein required.
- Multiple revisions within same date permitted to audit exact user decisions, but effective snapshot for the date is latest. Missing days inherit revision effective at that date. Initial revision created at install.

**achievements** (if storing instead of deriving)
- `achievementId: String` PK, `unlockedAtEpochMs`, `sourceDay`; computed from snapshots/events; no duplicate unlocking, no regressions after app restart.

**settings** in DataStore (or explicitly documented Room settings with same semantics)
- `firstInstallLocalDay`, `waterGoalMl`, `pushUpGoalReps`, `creatineEnabled`, `proteinEnabled`, theme choice, reminder toggles/times/intervals, reduced motion opt-out.
- Ensure consistent transaction ordering when changing settings and today's snapshot. If using separate stores, provide safe recovery on process death between commits.

## Repository contract

```
observeToday(): Flow<DayView>
observeDays(range): Flow<List<DayView>>
addWaterToday(amountMl)
undoWaterToday(entryId)
addPushUpSetToday(reps)
removePushUpSetToday(setId)
setCreatineDoneToday(done)
setProteinDoneToday(done)
updateWaterGoalTodayForward(goalMl)
updatePushUpGoalTodayForward(goalReps)
setSupplementTrackingTodayForward(habit, enabled)
reconcileDayBoundary()
exportBackup(destinationUri)
importBackup(sourceUri, replacementConfirmed)
```

All mutation methods must validate that day is TODAY. Never accept arbitrary date from widget/notifications. Room is source for history and log events. Stats derive from snapshots and events with no hardcoded samples.

## Data lifecycle

1. First open: create install date and config revision; `ensureToday` creates today's snapshot, totals=0.
2. On daily rollover/reopen: backfill day snapshots for missed days with historical effective config, preserve zero logs. Never rewrite locked past.
3. On goal/enable switch today: update current configuration, append revision, update today's required flags/goals; past untouched.
4. Backup exports all underlying tables and settings + manifest/checksum; import validates and applies atomic replacement.
5. Migrations: Room schema export=true; checked-in JSON migration schemas in `app/schemas/`. Each DB version bump requires migration tests.
