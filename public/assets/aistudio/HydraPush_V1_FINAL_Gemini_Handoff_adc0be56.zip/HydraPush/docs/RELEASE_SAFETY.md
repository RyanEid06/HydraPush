# Identity, signing, privacy, backups, and upgrade safety

## Identity / version

`applicationId = com.hydrapush.tracker` MUST remain constant across releases if old data should remain installed. `versionCode=1`, `versionName=1.0.0` for original V1; future release 1.1.0 must have larger versionCode. For Android upgrades install the new APK **over** the existing app, never uninstall to 'update'.

## Signing

A release update must be signed with the **same permanent private keystore/key** as the first installed release. Create once on user's own computer with Android Studio/keytool; back up the key in at least two secure locations. No keys/passwords in GitHub, source zip or Gemini prompts. If app initially installed as debug and future APK is release-signed, signatures differ; migration is NOT in-place. Test a release-signed V1 first to establish continuous upgrades.

## Persistence & migration

- `android:allowBackup="false"` for app/Android automatic cloud backup (explicit file export is allowed). No INTERNET permission.
- Room migrations for every schema bump; **never** call `fallbackToDestructiveMigration()` or wipe db on launch.
- Export Room schemas under `app/schemas/` and commit revisions.
- Pre-upgrade manual export strongly recommended; test upgrade on a copy before distributing.
- If crash during import, old DB remains intact; use staging and transactional replacement.
- Do not silently erase data for troubleshooting or 'sync'.

## User-controlled backup

Offline file-picker export/import, version and checksum verification, no external server. Explain exported unencrypted backups are readable to anyone with file access; either add optional password protection or show a clear warning. Data contains private activity records.

## Source / licensing

Brand art from images is a design reference; if using extracted icon/athlete imagery check provenance and user permission. Avoid copying screenshots as runtime UI.

## Builds

- Debug: `./gradlew :app:assembleDebug`.
- Unit tests: `./gradlew :app:testDebugUnitTest`.
- Emulator integration: `./gradlew :app:connectedDebugAndroidTest` with Android emulator running.
- Release: secure local signing config outside repository, `./gradlew :app:assembleRelease`, verify signed APK, `apksigner verify --verbose`, checksum with SHA-256.
- Never promise APK works before actually installing and launching it.
