# Product requirements — HydraPush V1

## Objective

Let a user log water and push-up sets within two taps, check off optional supplement habits, and understand progress without ads, accounts or connection.

## Information architecture

- **Dashboard** — live today data, input controls, optional habits, combined daily progress/streak.
- **Stats** — Overview, Water, Push-ups, History, Achievements (secondary detail screen/sheet).
- **Settings** — Daily Goals, Active Habits, Reminders, Appearance, Data/backup, About/version.

## Dashboard interactions

Water entries: quick buttons add exactly +150/+250/+500 ml, custom positive integer ml (input limits and validation), chronological event log and Undo last entry (today only). No goal cap: track over-goal values; visual ring is capped at 100%, numeric total uncapped. Reject duplicate submission from fast taps appropriately, but two intentional taps must add two separate entries.

Push-ups: Add Set bottom sheet accepts 1+ integer reps, adds a timestamped set for today, shows ordered chip/list; remove an accidentally added set today with a confirmation/undo. No editing historical sets.

Creatine and protein: each checked true/false at most one completion per local day; marking done may be undone **today only**. Unchecked is pending, not evidence of taking a supplement. When a supplement is disabled, hide its card, exclude it from current/next active requirement calculation, and stop its reminders; never delete a past entry.

Dashboard layout must remain usable with both optional habits disabled, one enabled, or both enabled. Show today's date in device locale. Empty initial states are real zeros, not fake sample data.

## Stats

Top range selection 7D/30D/90D/All affects overview and selected detail tab consistently. Define complete days and ratios precisely. Overview: perfect-day current/best streak, perfect days in selected range, completion rate of **fully completed days / eligible elapsed days**, 7-day daily progress chart, per-habit completion and records, accessible History/calendar and Achievements entry.

Water tab: range arithmetic average including zero-intake eligible dates, highest water amount and date, daily quantity bars and historical goal reference, hit-days count, consecutive hit streak, best consistency calendar week; show all numbers with units and explicit period.

Push-ups tab: range arithmetic average including zero-set days, best daily rep total/date, daily total bars, historical goal reference, hit-days count, consecutive goal-hit streak, best consistency week, and set history.

History: month navigation and selectable elapsed day. Past view read-only, with date, water total/goal, push-up total/goal and individual sets, supplement check statuses and requirements, completion score/perfect-day flag; today routes to dashboard. No historical editor hidden behind long-press.

## Goals & active habits

Goals are integers > 0, safe upper validation (water <= 20000ml, push-ups <= 10000 reps; adjustable if real use needs more). Changes to goals or active habits apply to **today and future local days only**, do not modify past snapshots. Previously recorded entry totals survive a goal change. Streak evaluation uses the goals and required flags captured for each day.

## Reminders

Each active habit can have independent reminders. Water can support time windows and interval option (e.g. every 2h) plus a fixed schedule; push-ups / creatine / protein can each use a daily time; all controls must have meaningful enabled/disabled and permission states. No notification for disabled habit. Notification clicking leads to relevant dashboard action and only changes today's state after deliberate user input.

## Widget

At least one real home-screen widget (small/medium adaptive); show today water and push-up progress, shortcut for water +250 and add push-up set or open app. Supplements appear only if active and adequate space exists. Widget cannot write to a past date. Update with database transaction result.

## Empty states/accessibility

Every statistics screen handles no data, fewer than 7 days, exceeding goals, and long histories. Text accessible at 1.3x and ideally 1.5x system scaling, 48dp min targets, colors plus labels to communicate status, TalkBack actions, high contrast and no essential content embedded in images.
