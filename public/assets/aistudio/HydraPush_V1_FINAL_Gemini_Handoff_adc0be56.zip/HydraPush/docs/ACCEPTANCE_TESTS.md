# HydraPush V1 acceptance tests — explicit pass/fail, do not fabricate outcomes

## Core logging
- [ ] Fresh install opens instantly with water=0/push-ups=0; no login; airplane mode supported.
- [ ] +150/+250/+500 water adds correct ml and persists after force-stop/reboot.
- [ ] Custom water validates empty, negative, decimal, impossible, huge values.
- [ ] 2500 target, 2600 total shows 104% numeric consumption but ring capped at 100%.
- [ ] Water Undo today removes exactly selected last entry, never another.
- [ ] Push-up sets 20+15+10 shown in insertion order, sum=45, persist after restart.
- [ ] Push-up set entry validation and today's set undo work; past sets immutable.
- [ ] Creatine/protein can be toggled done/undone today; no duplicate completions.

## Optional habit configuration + changing goals
- [ ] Disable both supplements: only two primary cards shown, perfect day requires only water+pushups; reminders off.
- [ ] Disable one: only that card disappears; other supplement still required.
- [ ] Re-enable: new active requirement appears; older entries preserved.
- [ ] Yesterday's required flags and streak result stay unchanged when toggling today.
- [ ] Changing daily goal updates TODAY, not yesterday or older; stats historical target lines remain correct.
- [ ] No complete day is fabricated for unused days when app was closed.
- [ ] Current streak excludes in-progress today, counts from yesterday until today perfect.
- [ ] Day rollover while app open, force stop across midnight, timezone change verified.

## Stats
- [ ] Overview does NOT show standalone Water/Push-up Average cards.
- [ ] Tapping Water or Push-ups opens correct detailed chart + average/record/date/goal hit/consistent week.
- [ ] 7D/30D/90D/All windows match and include zero days consistently.
- [ ] Multi-goal history draws correct changing goal markers.
- [ ] Best day ties & best complete week ties are documented and stable.
- [ ] Zero history, short history, all goals missed, all goals exceeded handled.
- [ ] History calendar opens past date read-only, with set list and supplement requirements.
- [ ] Achievements unlock once; no duplicated celebration after app restart.

## Reminders & widget
- [ ] Per-habit reminders use configured times, permission requested on Android 13+.
- [ ] Disabled habit reminder cancels; restored on re-enable only when its setting enabled.
- [ ] Denied permission does not crash; reboot/timezone reschedule where applicable.
- [ ] Widget updates after logging, goal toggle, new day and backup import.
- [ ] Small-widget actions avoid fake controls; tapping widget cannot write to yesterday.

## Backup & update safety
- [ ] Export backup using SAF succeeds offline and includes all records/config.
- [ ] Import valid backup into clean device restores exact totals/snapshots/changes.
- [ ] Tampered, truncated, unknown-version and oversized backups are rejected without partial overwrite.
- [ ] Wrong backup selected: user can cancel safely; replacement requires confirmation.
- [ ] Install v1 debug/release, create data, install **higher-version same-package same-signature APK** without uninstall, data persists.
- [ ] DB migration path tested (old schema to new) with exported Room schema JSON.
- [ ] Release APK install succeeds on target min Android version; no runtime INTERNET permission.

## Visual/accessibility
- [ ] Dashboard matches chosen light turquoise/lime reference; two main cards dominate.
- [ ] Stats Overview, Water, Push-ups, and Settings visually coherent with source mockups.
- [ ] Screenshot labels not hardcoded, no clipping at 360dp / increased font.
- [ ] Settings screen with Active Habits group fits on normal phone with scrolling.
- [ ] Light appearance default; if Follow System is shown, dark and light actually work.
- [ ] TalkBack labels correct, tap targets ≥44dp, progress bars explained in text.

## Reporting

For every checked item, include evidence: executed command/test/device, observed expected result, and relevant screenshot/log. Do not mark unchecked items 'green' based on reasoning alone.
