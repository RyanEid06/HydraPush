# Implement in checkpoints, no giant unverified code dump

| Phase | Scope | Exit gate |
|---|---|---|
| P0 | Inspect source, Gradle wrapper + toolchain, ensure native APK | assembleDebug & starter tests green |
| P1 | Room log entries, snapshots, DataStore, repo, date rollover | no loss after force stop; goal math tests green |
| P2 | Dashboard pixel-match, add/log/check/undo | all quick actions and empty states tested |
| P3 | Stats Overview, Water, Push-ups, History/calendar, achievements | stats manual test fixtures + unit tests |
| P4 | Settings Active Habits, editable goals, appearance, reminders | old snapshots unchanged, reminders stop when disabled |
| P5 | Offline backup import/export, schema migration test | damaged backup safely rejected; upgrade keeps logs |
| P6 | Widget, Android notifications, animations and a11y | widget actions persist, permission denied handled |
| P7 | Full QA; signed APK only with secure external keystore | every must-have test verified; no internet permission |

Prioritize P0–P5 core experience over minor illustration perfection. Never call a feature complete if it is just a graphic that looks like a control.
