# Locked owner decisions — HydraPush V1 (2026-11-03)

- App name: **HydraPush**. Audience: owner initially, perhaps more users later.
- Platform: **native Android APK only**.
- Data: **offline-only**, no account, local persistent storage and manual export/import.
- Branding: **approved bright light sporty look**, white/mist background, seafoam/aqua accents, lime green, soft coral, bold numbers; preserve image references.
- Nav: 3 bottom items: Dashboard, Stats, Settings. Inside Stats: Overview / Water / Push-ups plus discoverable History/calendar.
- Dashboard layout: two equal-dominance cards for water and push-ups; small supplements below. No forced dark design.
- Water: plain water ONLY, adjustable target, +150/+250/+500 ml, custom integer ml entry.
- Push-ups: standard push-ups, adjustable daily goal, logged by integer-rep sets, no rest-day schedule in V1.
- Creatine & protein: independent on/off tracking and once-per-day checkboxes. Both can be deactivated/reactivated **without losing history**. Water and push-ups cannot be deactivated.
- One daily perfect-day streak for ALL requirements **active on that day**. No automatic backdating; past days read-only.
- Stats: detailed trends, 7D/30D/90D/All, records, averages, consistency, streaks, monthly history, achievements. Water and push-up average cards ONLY in their drilldown tabs.
- Settings: minimal grouped UI; editable goals, active habits, four configurable notifications, appearance, backups, version.
- Widget: actual Android home-screen progress with quick logging when size allows.
- Motivation: moderate streaks/badges/subtle celebrations.
- No PIN/biometrics and no mandatory sign in. Open quickly.
- Update safety: stable Android applicationId, release key, Room migrations, portable backup.

## Non-goals for V1

- Calories/macros, grams of creatine, protein powder quantity, smartwatch, cloud sync, Apple/iOS, water sourced from other drinks, rest-day scheduling, social feeds, public leaderboard, camera pose tracking, AI-generated health advice.

## Default values — initial placeholders, owner can change

- Water goal: 2500 ml/day; push-ups: 100 reps/day. Both must be adjustable. These are NOT prescribed fitness targets.
- Creatine and protein enabled on a clean install; user can turn each off immediately.
- Do not hardcode screenshot values such as `2100 ml`, `72 reps`, `90%`, or `7-day streak` into runtime.

## Resolved ambiguity: theme

Owner originally selected Follow System and later preferred a very light colorful app, possibly light-only. For V1 deliver the **approved light appearance as the design priority**, and if an Appearance row says Follow System, it MUST actually work. Dark mode is optional for initial coding priorities; hide the control if not truly implemented. This choice does not authorize a dark default.
