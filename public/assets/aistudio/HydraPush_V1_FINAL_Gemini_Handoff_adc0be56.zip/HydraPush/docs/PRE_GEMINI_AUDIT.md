# Final pre-Gemini audit — 2026-11-03

This handoff was checked immediately before sending to Gemini / Google AI Studio.

## Passed package checks

- ZIP decompression/integrity check passed.
- Required approved PNG references are present and readable: Dashboard, Settings, Stats triptych, plus Overview/Water/Push-ups crops.
- `FILE_MANIFEST.json` and `design/tokens.json` parse successfully.
- `applicationId` is consistently `com.hydrapush.tracker`; V1 is `versionCode=1`, `versionName=1.0.0`.
- Android manifest contains **no INTERNET permission**. `POST_NOTIFICATIONS` is the only runtime-sensitive permission currently declared.
- `allowBackup=false` is set so Android cloud/device backup does not silently copy private activity data; manual user-controlled export/import is the required backup path.
- Pure Kotlin `ProgressMath` was compiled and exercised with a small harness for current streak, longest streak, optional-habit perfect-day behavior; checks passed.
- Product docs consistently require water + push-ups always active, supplements independently optional, past days immutable, and goal/requirement snapshots frozen historically.
- Approved Stats structure is consistent: Overview has no large water/push-up average cards; those metrics belong in Water/Push-ups drilldowns.

## Toolchain sanity check

At audit time the selected Android versions are real/current enough to be a sensible starting point: AGP 9.2.1 pairs with Gradle 9.4.1, Compose BOM 2026.08.00 is a current stable BOM, Room 2.8.5 and Glance 1.2.0 are released versions, and KSP 2.3.10 supports modern AGP 9 projects. **Gemini must still run a real Gradle sync/build and may repin compatible stable versions if the actual build requires it.** Do not change app behavior or identity merely to chase dependency versions.

## Intentionally NOT verified here

- Full Android/Gradle build: this environment did not have an Android SDK/Gradle distribution ready for the project.
- Official `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar` are intentionally absent. Gemini's first technical task is to generate the official Gradle wrapper and commit it after verification.
- Real widget, reminders, backup/restore, achievements, polished charts/calendar, robust rollover/timezone handling, release signing, and device/emulator QA remain implementation work. Their placeholder/stub files must not be mistaken for completed features.

## First Gemini gate

Before feature expansion:

1. Read `GEMINI_START_HERE.md` and all docs it references.
2. Generate the official Gradle wrapper.
3. Sync and run `:app:assembleDebug` and `:app:testDebugUnitTest`.
4. Fix build/toolchain issues without changing `applicationId`, product rules, or approved visual direction.
5. Only after the baseline build is green, continue phase-by-phase implementation and tests.

## GitHub rule

When a repository is created later, initialize it from the verified project. Commit source, docs, design references, wrapper scripts/JAR, Room schemas and CI. Never commit `local.properties`, APK build outputs, keystores, signing passwords, or other secrets. Preserve the same package name and permanent release signing identity for future in-place upgrades.
