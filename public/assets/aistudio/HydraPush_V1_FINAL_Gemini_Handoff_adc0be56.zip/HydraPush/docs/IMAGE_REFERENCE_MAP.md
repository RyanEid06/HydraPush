# Reference image manifest

| File | Purpose |
|---|---|
| `V1-Design/HydraPush Dashboard.png` | Approved original dashboard |
| `V1-Design/HydraPush Settings Dashboard.png` | Approved minimal Settings; ADD Active Habits card |
| `V1-Design/HydraPush Stats Dashboard Trio.png` | Approved 3-state Stats composition |
| `V1-Design/Stats Overview.png` | Crop from Stats trio left third: Overview |
| `V1-Design/Stats Water.png` | Crop from Stats trio middle third: Water details |
| `V1-Design/Stats Push Ups.png` | Crop from Stats trio right third: Push-ups details |

**Images contain illustrative sample data** and smartphone framing. They are NOT rendered app assets. Do not ship them inside `app/src/main/res/drawable` as screen-sized images. The intended interface is recreated in Compose and driven by Room records.
