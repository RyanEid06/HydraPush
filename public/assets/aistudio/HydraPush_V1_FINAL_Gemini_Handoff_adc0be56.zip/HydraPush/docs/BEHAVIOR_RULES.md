# Precise behavior and math

## Local dates

Use device local calendar dates (`yyyy-MM-dd` with `java.time.LocalDate`) as day keys. Entry time stored in UTC epoch milliseconds; store timezone identifier on entry if useful for audit. At each resume/start or calendar rollover, reconcile missing days and update observers/widget. Today can be edited only if equal to current local date and not finalized; past days are permanently read-only through every entry path, including widget and backup (restore can replace history only as a whole with explicit warning).

Do NOT assign entries to yesterday because the user woke up late. The new local day begins at local midnight. For timezone changes, preserve historical date keys and don't relabel past records.

## Day snapshot

Each date has its own frozen requirements `waterGoalMl`, `pushUpGoalReps`, `creatineRequired`, `proteinRequired`, created from configuration revision effective for that local date. Settings changed on *today* replace only today's snapshot and effective config revision. Past snapshots immutable, even when toggles change later. Lazy backfill missing days using configuration history effective for each day so days without app use count incomplete rather than vanish.

If no record exists yet for a previous elapsed date, consider it zero-completion using effective configuration; do not invent a successful day. Initial installation date is the earliest eligible day: pre-install dates do not count as failures or streak entries.

## Perfect-day criteria

`waterMet = sum(water entries)>=snap.waterGoalMl`

`pushMet = sum(push-up sets)>=snap.pushUpGoalReps`

`creatineMet = !snap.creatineRequired || snap.creatineDone`

`proteinMet = !snap.proteinRequired || snap.proteinDone`

`perfect = waterMet && pushMet && creatineMet && proteinMet`

`progressFraction = (min(1, water/waterGoal) + min(1,push/pushGoal) + (creatineDone?1:0 if required) + (proteinDone?1:0 if required)) / (2 + int(creatineRequired) + int(proteinRequired))`

For clarity, the score is a fractional **weighted goal progress** for the day; the completion rate in Stats is the **percentage of elapsed days that were perfect**, NOT the weighted daily progress. Keep both labeled accurately.

## Streak behavior

Only perfect days count. Current perfect-day streak counts backward from *today if today is perfect*, otherwise from **yesterday** so an unfinished current day doesn't break yesterday's active streak. If yesterday failed, current streak is 0 until today becomes perfect. Best streak is longest consecutive perfect dates since first eligible day. Calculate from each day's saved snapshot (never current settings). Do not retroactively award past days when a habit is turned off.

## Consistency, averages, records

- Eligible window covers complete elapsed dates from install date through today. Show 'in progress' for today, exclude today from final completion-rate denominator until end of day (or explicitly label live provisional results). Prefer excluding today's in-progress day from summary completion % to avoid punishing the user while they work.
- Water average per day = total logged water across eligible displayed dates / number of eligible dates (including zero days). Similar for push-ups. Daily average is NOT average of recorded-only days.
- Habit goal-hit rate = `dates meeting that habit's historical goal / dates where that habit was required` for optional habits; water/pushups always required. Show N/A if denominator 0.
- Week consistency = calendar-week (Mon–Sun) percentage days meeting that habit's target; label partial current weeks. For best full week use complete 7-day weeks only; if no full weeks, say 'Not enough history'. If equal max rate, choose latest; show dates and percent.
- Best day = max logged amount/reps across eligible dates with real date; ties choose earliest date, documented consistently.
- Never cap underlying data at goal; bar relative scaling supports >100%.
- Changes in historical goals should be reflected in chart targets per day (line/markers) rather than a single misleading flat target.

## Undo and duplicate prevention

Database mutation transactional; use unique entry identifiers. Distinct taps intentionally add distinct entries; prevent accidental duplicate submit from one long interaction (e.g. disable confirm while saving). Deleting today's row only through deliberate Undo/Remove. No negative totals, no rollback of a prior local day.

## Backups

Backup contains a versioned app-data envelope, schema revision, all daily snapshots, entries, settings/revisions, achievements and reminder preferences. Use content URI file picker; validate format/size/checksums/dates/IDs/schema before import. Import should be transactional + atomic; never partly overwrite good data. Backups are user-controlled unencrypted unless an optional password-protected encrypted export is deliberately implemented; say so clearly.
