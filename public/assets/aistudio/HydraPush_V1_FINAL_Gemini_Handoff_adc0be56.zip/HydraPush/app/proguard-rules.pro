# Generated serialization, Room etc. must be tested in release. Add only justified rules.
