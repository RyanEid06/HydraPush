package com.hydrapush.tracker.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.trackerDataStore by preferencesDataStore(name = "hydrapush_settings")

data class TrackerSettings(
    val waterGoalMl: Int = 2500,
    val pushUpGoalReps: Int = 100,
    val creatineEnabled: Boolean = true,
    val proteinEnabled: Boolean = true
)

class TrackerSettingsStore(private val context: Context) {
    private object Keys {
        val WATER_GOAL = intPreferencesKey("water_goal_ml")
        val PUSH_GOAL = intPreferencesKey("push_goal_reps")
        val CREATINE = booleanPreferencesKey("creatine_enabled")
        val PROTEIN = booleanPreferencesKey("protein_enabled")
    }
    val settings: Flow<TrackerSettings> = context.trackerDataStore.data.map { p ->
        TrackerSettings(
            p[Keys.WATER_GOAL] ?: 2500,
            p[Keys.PUSH_GOAL] ?: 100,
            p[Keys.CREATINE] ?: true,
            p[Keys.PROTEIN] ?: true
        )
    }
    suspend fun save(next: TrackerSettings) {
        require(next.waterGoalMl in 1..20000 && next.pushUpGoalReps in 1..10000)
        context.trackerDataStore.edit { p ->
            p[Keys.WATER_GOAL] = next.waterGoalMl
            p[Keys.PUSH_GOAL] = next.pushUpGoalReps
            p[Keys.CREATINE] = next.creatineEnabled
            p[Keys.PROTEIN] = next.proteinEnabled
        }
    }
}
