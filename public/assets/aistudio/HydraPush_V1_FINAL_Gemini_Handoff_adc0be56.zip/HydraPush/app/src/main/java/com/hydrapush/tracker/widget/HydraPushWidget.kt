package com.hydrapush.tracker.widget

/**
 * TODO(P6): Real Glance AppWidget and action callbacks.
 * Widget must share SAME Room repository as app and verify local today before writes.
 * Do not add widget receiver into manifest until implemented and tested.
 */
internal object HydraPushWidgetContract
