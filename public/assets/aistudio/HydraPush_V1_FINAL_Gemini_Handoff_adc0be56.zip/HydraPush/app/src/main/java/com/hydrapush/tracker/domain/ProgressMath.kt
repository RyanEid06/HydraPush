package com.hydrapush.tracker.domain

import java.time.LocalDate
import kotlin.math.min

data class DailyMetrics(
    val day: LocalDate,
    val waterMl: Int,
    val pushUpReps: Int,
    val waterGoalMl: Int,
    val pushUpGoalReps: Int,
    val creatineRequired: Boolean,
    val proteinRequired: Boolean,
    val creatineDone: Boolean,
    val proteinDone: Boolean
) {
    init { require(waterGoalMl > 0 && pushUpGoalReps > 0) }
    val waterMet get() = waterMl >= waterGoalMl
    val pushUpsMet get() = pushUpReps >= pushUpGoalReps
    val perfect get() = waterMet && pushUpsMet &&
        (!creatineRequired || creatineDone) && (!proteinRequired || proteinDone)
    val progress: Float get() {
        val total = 2 + (if (creatineRequired) 1 else 0) + (if (proteinRequired) 1 else 0)
        var earned = min(1f, waterMl.toFloat() / waterGoalMl) +
            min(1f, pushUpReps.toFloat() / pushUpGoalReps)
        if (creatineRequired && creatineDone) earned += 1f
        if (proteinRequired && proteinDone) earned += 1f
        return (earned / total).coerceIn(0f, 1f)
    }
}

object ProgressMath {
    /** Today being incomplete does not erase a streak earned through yesterday. */
    fun currentPerfectStreak(days: List<DailyMetrics>, today: LocalDate): Int {
        val map = days.associateBy { it.day }
        var cursor = if (map[today]?.perfect == true) today else today.minusDays(1)
        var count = 0
        while (map[cursor]?.perfect == true) { count++; cursor = cursor.minusDays(1) }
        return count
    }

    fun longestPerfectStreak(days: List<DailyMetrics>): Int {
        val sorted = days.sortedBy { it.day }
        var best = 0; var running = 0; var previous: LocalDate? = null
        for (d in sorted) {
            running = if (d.perfect) {
                if (previous == d.day.minusDays(1)) running + 1 else 1
            } else 0
            best = maxOf(best, running)
            previous = d.day
        }
        return best
    }
}
