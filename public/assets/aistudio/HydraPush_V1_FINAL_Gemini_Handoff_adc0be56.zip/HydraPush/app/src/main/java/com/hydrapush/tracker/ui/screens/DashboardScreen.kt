package com.hydrapush.tracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hydrapush.tracker.data.repository.DayView
import com.hydrapush.tracker.data.repository.TrackerRepository
import com.hydrapush.tracker.domain.ProgressMath
import com.hydrapush.tracker.ui.components.BrandHeader
import com.hydrapush.tracker.ui.components.SectionCard
import com.hydrapush.tracker.ui.theme.HydraColors
import java.time.LocalDate
import kotlinx.coroutines.launch

@Composable
fun DashboardScreen(repository: TrackerRepository, today: DayView?, days: List<DayView>) {
    val scope = rememberCoroutineScope()
    var showWater by remember { mutableStateOf(false) }
    var showPush by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val metrics = today?.metrics
    val streak = ProgressMath.currentPerfectStreak(days.map { it.metrics }, LocalDate.now())

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        BrandHeader("Daily performance")
        Text("Today", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(LocalDate.now().toString(), color = HydraColors.Muted)
        Spacer(Modifier.height(12.dp))
        if (metrics == null) {
            CircularProgressIndicator(); Text("Loading today's log...")
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(Modifier.weight(1f), shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = HydraColors.TealCard)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("💧 Water", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(progress = { (metrics.waterMl.toFloat() / metrics.waterGoalMl.coerceAtLeast(1)).coerceIn(0f, 1f) },
                                color = HydraColors.Aqua, trackColor = Color(0xFFD5E8E9), strokeWidth = 8.dp, modifier = Modifier.size(108.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${metrics.waterMl} ml", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                                Text("/ ${metrics.waterGoalMl}", fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        listOf(150,250,500).forEach { amount ->
                            OutlinedButton(onClick = { scope.launch { repository.addWater(amount) } },
                                modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(4.dp)) { Text("+$amount ml", fontSize = 12.sp) }
                        }
                        TextButton(onClick = { input = ""; error = null; showWater = true }, modifier = Modifier.fillMaxWidth()) { Text("Custom amount") }
                        today.waters.lastOrNull()?.let { last ->
                            TextButton(onClick = { scope.launch { repository.undoWater(last.id) } }, modifier = Modifier.fillMaxWidth()) { Text("Undo last") }
                        }
                    }
                }
                Card(Modifier.weight(1f), shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = HydraColors.GreenCard)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Push-ups", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(18.dp))
                        Text("${metrics.pushUpReps}", fontSize = 30.sp, color = HydraColors.Navy, fontWeight = FontWeight.ExtraBold)
                        Text("/ ${metrics.pushUpGoalReps} reps", fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(progress = { (metrics.pushUpReps.toFloat()/metrics.pushUpGoalReps).coerceIn(0f,1f) },
                            modifier=Modifier.fillMaxWidth(), color=HydraColors.Lime, trackColor=Color(0xFFDCE9D5))
                        Spacer(Modifier.height(18.dp))
                        Text("Today's sets", fontSize = 12.sp, color = HydraColors.Muted)
                        Text(if (today.sets.isEmpty()) "No sets yet" else today.sets.joinToString(" + ") { it.reps.toString() },
                            fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { input = ""; error = null; showPush = true },
                            colors=ButtonDefaults.buttonColors(containerColor=HydraColors.Lime, contentColor=HydraColors.Navy),
                            modifier=Modifier.fillMaxWidth(), contentPadding=PaddingValues(8.dp)) { Text("+ Add set", fontSize = 12.sp) }
                        today.sets.lastOrNull()?.let { last ->
                            TextButton(onClick = { scope.launch { repository.removeSet(last.id) } }, modifier = Modifier.fillMaxWidth()) { Text("Undo last") }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            if (today.snapshot.creatineRequired || today.snapshot.proteinRequired) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    if (today.snapshot.creatineRequired) {
                        SupplementCard("Creatine", today.snapshot.creatineDone, Modifier.weight(1f)) {
                            scope.launch { repository.setSupplementDone(true, it) }
                        }
                    }
                    if (today.snapshot.proteinRequired) {
                        SupplementCard("Protein shake", today.snapshot.proteinDone, Modifier.weight(1f)) {
                            scope.launch { repository.setSupplementDone(false, it) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            SectionCard(Modifier.fillMaxWidth()) {
                Text("🔥 $streak-day streak", fontWeight = FontWeight.Bold)
                Text("Daily progress ${(metrics.progress * 100).toInt()}% · ${if (metrics.perfect) "Perfect day!" else "Keep going"}",
                    color = HydraColors.Muted)
                LinearProgressIndicator(progress = { metrics.progress }, modifier=Modifier.fillMaxWidth().padding(top=8.dp),
                    color=HydraColors.Aqua)
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showWater || showPush) {
        val water = showWater
        AlertDialog(onDismissRequest = { showWater = false; showPush = false },
            title = { Text(if (water) "Add water" else "Add push-up set") },
            text = {
                Column {
                    OutlinedTextField(value=input, onValueChange={ input=it.filter(Char::isDigit); error=null },
                        label={ Text(if (water) "Amount (ml)" else "Repetitions") }, singleLine=true)
                    if (error != null) Text(error!!, color=MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick={
                    val value=input.toIntOrNull()
                    if (value==null || value !in 1..(if (water) 5000 else 1000)) {
                        error = "Enter a valid positive amount"
                    } else {
                        scope.launch { if(water) repository.addWater(value) else repository.addSet(value) }
                        showWater = false; showPush = false
                    }
                }) { Text("Save") }
            },
            dismissButton={ TextButton(onClick={showWater=false;showPush=false}) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SupplementCard(name: String, done: Boolean, modifier: Modifier, onChange: (Boolean)->Unit) {
    Card(modifier, shape=RoundedCornerShape(18.dp),
        colors=CardDefaults.cardColors(containerColor=if (name=="Creatine") HydraColors.TealCard else HydraColors.RedCard)) {
        Column(Modifier.padding(12.dp)) {
            Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(if (done) "Done" else "Pending", fontSize=12.sp, modifier=Modifier.weight(1f))
                Checkbox(checked=done, onCheckedChange=onChange)
            }
        }
    }
}
