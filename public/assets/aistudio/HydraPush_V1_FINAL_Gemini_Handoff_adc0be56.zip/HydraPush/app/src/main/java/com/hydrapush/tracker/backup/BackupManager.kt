package com.hydrapush.tracker.backup

/**
 * TODO(P5): User-initiated Android Storage Access Framework JSON/binary backup
 * with manifest, schema version, SHA-256, strict validation and atomic restore.
 * No implementation is provided in this starter; no fake export buttons should ship.
 * See docs/RELEASE_SAFETY.md and docs/DATA_MODEL.md.
 */
internal object BackupManagerContract
