package com.hydrapush.tracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hydrapush.tracker.data.preferences.TrackerSettings
import com.hydrapush.tracker.data.repository.TrackerRepository
import com.hydrapush.tracker.ui.components.BrandHeader
import com.hydrapush.tracker.ui.components.SectionCard
import com.hydrapush.tracker.ui.theme.HydraColors
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(repo: TrackerRepository, settings: TrackerSettings) {
    val scope= rememberCoroutineScope()
    var goalDialog by remember { mutableStateOf<String?>(null) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        BrandHeader("Settings & preferences")
        Text("Settings", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        SectionCard(Modifier.fillMaxWidth()) {
            Text("Daily Goals", fontWeight=FontWeight.Bold, color=HydraColors.Navy)
            TextButton(onClick={input=settings.waterGoalMl.toString();goalDialog="water";error=null}) {
                Text("Water Goal   ${settings.waterGoalMl} ml  ›")
            }
            TextButton(onClick={input=settings.pushUpGoalReps.toString();goalDialog="push";error=null}) {
                Text("Push-up Goal   ${settings.pushUpGoalReps} reps  ›")
            }
        }
        Spacer(Modifier.height(12.dp))
        SectionCard(Modifier.fillMaxWidth()) {
            Text("Active Habits",fontWeight=FontWeight.Bold)
            Text("💧 Water                            Always active", color=HydraColors.Muted)
            Text("↗ Push-ups                       Always active",color=HydraColors.Muted)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("Creatine",modifier=Modifier.weight(1f))
                Switch(settings.creatineEnabled, onCheckedChange={ enabled ->
                    scope.launch { repo.updateSettings { it.copy(creatineEnabled=enabled) } }
                })
            }
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("Protein shake",modifier=Modifier.weight(1f))
                Switch(settings.proteinEnabled, onCheckedChange={ enabled ->
                    scope.launch { repo.updateSettings { it.copy(proteinEnabled=enabled) } }
                })
            }
        }
        Spacer(Modifier.height(12.dp))
        SectionCard(Modifier.fillMaxWidth()) {
            Text("Reminders", fontWeight=FontWeight.Bold)
            Text("Water · Push-ups · Creatine · Protein shake", color=HydraColors.Muted)
            Text("Notification controls and Android permission/scheduling will be added during Gemini phase P4.", style=MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(12.dp))
        SectionCard(Modifier.fillMaxWidth()) {
            Text("Appearance", fontWeight=FontWeight.Bold)
            Text("Light · approved design",color=HydraColors.Muted)
        }
        Spacer(Modifier.height(12.dp))
        SectionCard(Modifier.fillMaxWidth()) {
            Text("Data", fontWeight=FontWeight.Bold)
            Text("Export / Import Backup",color=HydraColors.Muted)
            Text("Requires SAF + validated atomic restore (Gemini phase P5).",style=MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(12.dp))
        SectionCard(Modifier.fillMaxWidth()) {
            Text("About", fontWeight=FontWeight.Bold)
            Text("HydraPush · v1.0.0 starter",color=HydraColors.Muted)
        }
        Spacer(Modifier.height(24.dp))
    }
    goalDialog?.let { target ->
        AlertDialog(onDismissRequest={goalDialog=null},
            title={Text(if(target=="water") "Daily water goal (ml)" else "Daily push-up goal")},
            text={Column {
                OutlinedTextField(input, onValueChange={input=it.filter(Char::isDigit);error=null},singleLine=true)
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
            }},
            confirmButton={TextButton(onClick={
                val value=input.toIntOrNull();val limit=if(target=="water") 20000 else 10000
                if(value==null||value !in 1..limit) error="Enter an amount from 1 to $limit"
                else { scope.launch { repo.updateSettings {
                    if(target=="water") it.copy(waterGoalMl=value) else it.copy(pushUpGoalReps=value)
                } };goalDialog=null }
            }){Text("Save")}},
            dismissButton={TextButton(onClick={goalDialog=null}){Text("Cancel")}})
    }
}
