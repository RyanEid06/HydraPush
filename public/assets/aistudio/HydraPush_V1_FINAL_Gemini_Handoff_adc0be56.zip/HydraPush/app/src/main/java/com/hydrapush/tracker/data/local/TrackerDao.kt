package com.hydrapush.tracker.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackerDao {
    @Query("SELECT * FROM daily_snapshots ORDER BY day ASC")
    fun observeSnapshots(): Flow<List<DailySnapshotEntity>>

    @Query("SELECT * FROM water_entries ORDER BY createdAtEpochMs ASC, id ASC")
    fun observeWater(): Flow<List<WaterEntryEntity>>

    @Query("SELECT * FROM push_up_sets ORDER BY createdAtEpochMs ASC, id ASC")
    fun observePushUpSets(): Flow<List<PushUpSetEntity>>

    @Query("SELECT * FROM daily_snapshots WHERE day = :day LIMIT 1")
    suspend fun getSnapshot(day: String): DailySnapshotEntity?

    @Query("SELECT MAX(day) FROM daily_snapshots")
    suspend fun mostRecentDay(): String?

    @Query("SELECT * FROM configuration_revisions WHERE effectiveLocalDay <= :day ORDER BY effectiveLocalDay DESC, id DESC LIMIT 1")
    suspend fun getRevisionOnOrBefore(day: String): ConfigurationRevisionEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSnapshot(record: DailySnapshotEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSnapshot(record: DailySnapshotEntity)

    @Insert
    suspend fun insertWater(entry: WaterEntryEntity): Long

    @Insert
    suspend fun insertPushUpSet(set: PushUpSetEntity): Long

    @Insert
    suspend fun insertRevision(revision: ConfigurationRevisionEntity): Long

    @Query("DELETE FROM water_entries WHERE id = :id AND day = :today")
    suspend fun removeWaterToday(id: Long, today: String): Int

    @Query("DELETE FROM push_up_sets WHERE id = :id AND day = :today")
    suspend fun removePushUpSetToday(id: Long, today: String): Int
}
