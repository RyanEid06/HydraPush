package com.hydrapush.tracker.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.hydrapush.tracker.data.repository.TrackerRepository
import com.hydrapush.tracker.ui.screens.DashboardScreen
import com.hydrapush.tracker.ui.screens.StatsScreen
import com.hydrapush.tracker.ui.screens.SettingsScreen
import com.hydrapush.tracker.ui.theme.HydraColors
import com.hydrapush.tracker.ui.theme.HydraTheme
import java.time.LocalDate
import kotlinx.coroutines.delay

private enum class MainTab { Dashboard, Stats, Settings }

@Composable
fun HydraPushApp(context: Context) {
    val repository = remember(context) { TrackerRepository(context.applicationContext) }
    val days by repository.days.collectAsState(initial = emptyList())
    val settings by repository.settings.collectAsState(initial = com.hydrapush.tracker.data.preferences.TrackerSettings())
    var tab by remember { mutableStateOf(MainTab.Dashboard) }
    var localToday by remember { mutableStateOf(LocalDate.now()) }

    // Starter rollover poll. Gemini should add lifecycle/timezone/reboot handling and test it.
    LaunchedEffect(repository) {
        while (true) {
            localToday = LocalDate.now()
            repository.reconcileToday()
            delay(60_000)
        }
    }

    HydraTheme {
        Scaffold(
            containerColor = HydraColors.Mist,
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
                    listOf(
                        Triple(MainTab.Dashboard, "Dashboard", Icons.Default.Home),
                        Triple(MainTab.Stats, "Stats", Icons.Default.BarChart),
                        Triple(MainTab.Settings, "Settings", Icons.Default.Settings)
                    ).forEach { (destination, title, icon) ->
                        NavigationBarItem(
                            selected = tab == destination,
                            onClick = { tab = destination },
                            icon = { Icon(icon, contentDescription = title) },
                            label = { Text(title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = HydraColors.Navy,
                                selectedTextColor = HydraColors.Navy,
                                indicatorColor = HydraColors.TealCard)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
                when (tab) {
                    MainTab.Dashboard -> DashboardScreen(repository, days.find { it.snapshot.day == localToday.toString() }, days)
                    MainTab.Stats -> StatsScreen(days, localToday)
                    MainTab.Settings -> SettingsScreen(repository, settings)
                }
            }
        }
    }
}
