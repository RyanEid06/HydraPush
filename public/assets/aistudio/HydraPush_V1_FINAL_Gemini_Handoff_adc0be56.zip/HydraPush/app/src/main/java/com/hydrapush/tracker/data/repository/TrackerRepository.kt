package com.hydrapush.tracker.data.repository

import android.content.Context
import androidx.room.Room
import com.hydrapush.tracker.data.local.*
import com.hydrapush.tracker.data.preferences.TrackerSettings
import com.hydrapush.tracker.data.preferences.TrackerSettingsStore
import com.hydrapush.tracker.domain.DailyMetrics
import java.time.LocalDate
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Functional V1 data-layer STARTER. Gemini must complete robust midnight,
 * backup, revisions/import, transaction/recovery and analytics requirements.
 * Do not ship as fully production-verified without the acceptance suite. */
data class DayView(
    val snapshot: DailySnapshotEntity,
    val waters: List<WaterEntryEntity>,
    val sets: List<PushUpSetEntity>
) {
    val totalWater get() = waters.sumOf { it.amountMl }
    val totalReps get() = sets.sumOf { it.reps }
    val metrics get() = DailyMetrics(
        day = LocalDate.parse(snapshot.day), waterMl = totalWater,
        pushUpReps = totalReps, waterGoalMl = snapshot.waterGoalMl,
        pushUpGoalReps = snapshot.pushUpGoalReps,
        creatineRequired = snapshot.creatineRequired,
        proteinRequired = snapshot.proteinRequired,
        creatineDone = snapshot.creatineDone, proteinDone = snapshot.proteinDone
    )
}

class TrackerRepository(context: Context) {
    private val database = Room.databaseBuilder(context.applicationContext,
        TrackerDatabase::class.java, "hydrapush.db").build()
    private val dao = database.dao()
    val settingsStore = TrackerSettingsStore(context.applicationContext)
    val settings = settingsStore.settings
    private val mutex = Mutex()
    private fun today() = LocalDate.now().toString()

    val days: Flow<List<DayView>> = combine(
        dao.observeSnapshots(), dao.observeWater(), dao.observePushUpSets()
    ) { snapshots, water, sets ->
        snapshots.map { s -> DayView(s, water.filter { it.day == s.day }, sets.filter { it.day == s.day }) }
    }

    suspend fun reconcileToday() = mutex.withLock {
        val date = today()
        val settings = settings.first()
        val recent = dao.mostRecentDay()
        if (recent != null) {
            var cursor = LocalDate.parse(recent).plusDays(1)
            val end = LocalDate.parse(date)
            while (cursor.isBefore(end)) {
                val rev = dao.getRevisionOnOrBefore(cursor.toString())
                val fallback = settings
                dao.insertSnapshot(DailySnapshotEntity(cursor.toString(),
                    rev?.waterGoalMl ?: fallback.waterGoalMl,
                    rev?.pushUpGoalReps ?: fallback.pushUpGoalReps,
                    rev?.creatineRequired ?: fallback.creatineEnabled,
                    rev?.proteinRequired ?: fallback.proteinEnabled))
                cursor = cursor.plusDays(1)
            }
        }
        if (dao.getSnapshot(date) == null) {
            dao.insertSnapshot(DailySnapshotEntity(date, settings.waterGoalMl,
                settings.pushUpGoalReps, settings.creatineEnabled, settings.proteinEnabled))
            dao.insertRevision(ConfigurationRevisionEntity(effectiveLocalDay = date,
                waterGoalMl = settings.waterGoalMl, pushUpGoalReps = settings.pushUpGoalReps,
                creatineRequired = settings.creatineEnabled, proteinRequired = settings.proteinEnabled))
        }
    }

    suspend fun addWater(amount: Int) {
        require(amount in 1..5000) { "Water entry must be 1–5000 ml" }
        reconcileToday()
        dao.insertWater(WaterEntryEntity(day = today(), amountMl = amount))
    }
    suspend fun addSet(reps: Int) {
        require(reps in 1..1000) { "Set must be 1–1000 reps" }
        reconcileToday()
        dao.insertPushUpSet(PushUpSetEntity(day = today(), reps = reps))
    }
    suspend fun undoWater(entryId: Long) { dao.removeWaterToday(entryId, today()) }
    suspend fun removeSet(setId: Long) { dao.removePushUpSetToday(setId, today()) }
    suspend fun setSupplementDone(creatine: Boolean, done: Boolean) = mutex.withLock {
        val date = today()
        val current = dao.getSnapshot(date) ?: return@withLock
        if ((creatine && !current.creatineRequired) || (!creatine && !current.proteinRequired)) return@withLock
        dao.upsertSnapshot(if (creatine) current.copy(creatineDone = done)
            else current.copy(proteinDone = done))
    }
    suspend fun updateSettings(transform: (TrackerSettings) -> TrackerSettings) = mutex.withLock {
        val next = transform(settings.first())
        settingsStore.save(next)
        val date = today()
        val prior = dao.getSnapshot(date)
        if (prior != null) {
            dao.upsertSnapshot(prior.copy(waterGoalMl = next.waterGoalMl,
                pushUpGoalReps = next.pushUpGoalReps,
                creatineRequired = next.creatineEnabled,
                proteinRequired = next.proteinEnabled))
        } else {
            dao.insertSnapshot(DailySnapshotEntity(date, next.waterGoalMl,
                next.pushUpGoalReps, next.creatineEnabled, next.proteinEnabled))
        }
        dao.insertRevision(ConfigurationRevisionEntity(effectiveLocalDay = date,
            waterGoalMl = next.waterGoalMl, pushUpGoalReps = next.pushUpGoalReps,
            creatineRequired = next.creatineEnabled, proteinRequired = next.proteinEnabled))
    }
}
