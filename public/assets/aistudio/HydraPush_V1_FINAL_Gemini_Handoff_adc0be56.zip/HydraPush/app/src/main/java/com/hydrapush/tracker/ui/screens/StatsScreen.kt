package com.hydrapush.tracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hydrapush.tracker.data.repository.DayView
import com.hydrapush.tracker.domain.ProgressMath
import com.hydrapush.tracker.ui.components.BrandHeader
import com.hydrapush.tracker.ui.components.SectionCard
import com.hydrapush.tracker.ui.theme.HydraColors
import java.time.LocalDate

@Composable
fun StatsScreen(allDays: List<DayView>, today: LocalDate) {
    var selected by remember { mutableStateOf("Overview") }
    var range by remember { mutableStateOf("7D") }
    var history by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<DayView?>(null) }
    val start = when(range) { "7D"->today.minusDays(6);"30D"->today.minusDays(29);"90D"->today.minusDays(89);else->LocalDate.MIN }
    val selectedDays = allDays.filter { !LocalDate.parse(it.snapshot.day).isBefore(start) &&
        !LocalDate.parse(it.snapshot.day).isAfter(today) }
    val metrics = allDays.map { it.metrics }
    val perfectDays = selectedDays.count { it.metrics.perfect }
    val streak = ProgressMath.currentPerfectStreak(metrics, today)
    val longest = ProgressMath.longestPerfectStreak(metrics)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        BrandHeader("Your progress & performance")
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically,
            horizontalArrangement=Arrangement.SpaceBetween) {
            Text("Stats", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
            Row(horizontalArrangement=Arrangement.spacedBy(2.dp)) {
                listOf("7D","30D","90D","All").forEach { r ->
                    FilterChip(selected=range==r, onClick={range=r}, label={Text(r, fontSize=11.sp)})
                }
            }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("Overview","Water","Push-ups").forEach { s ->
                FilterChip(selected=selected==s, onClick={selected=s;history=false;detail=null},
                    label={Text(s, fontSize=12.sp)})
            }
        }
        Spacer(Modifier.height(8.dp))
        if (history) {
            TextButton(onClick={history=false;detail=null}) { Text("← Back to Stats") }
            Text("History (read-only)", fontWeight=FontWeight.Bold)
            selectedDays.reversed().forEach { day ->
                SectionCard(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable { detail=day }) {
                    Text(day.snapshot.day, fontWeight=FontWeight.Bold)
                    Text("Water ${day.totalWater} ml · Push-ups ${day.totalReps} · ${if (day.metrics.perfect) "Perfect" else "Incomplete"}", fontSize=12.sp)
                }
            }
            detail?.let { d ->
                AlertDialog(onDismissRequest={detail=null}, title={Text(d.snapshot.day)},
                    text={Text("Water ${d.totalWater}/${d.snapshot.waterGoalMl} ml
"+
                        "Push-ups ${d.totalReps}/${d.snapshot.pushUpGoalReps} reps
"+
                        "Sets: ${d.sets.joinToString { it.reps.toString() }}
"+
                        "Creatine: ${if(d.snapshot.creatineRequired) d.snapshot.creatineDone.toString() else "Not required"}
"+
                        "Protein shake: ${if(d.snapshot.proteinRequired) d.snapshot.proteinDone.toString() else "Not required"}")},
                    confirmButton={TextButton(onClick={detail=null}){Text("Close")}})
            }
        } else if (selected=="Overview") {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Kpi("🔥", "$streak", "Day streak", Modifier.weight(1f))
                Kpi("🏆", "$longest", "Best streak", Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            val finished = selectedDays.filter { it.snapshot.day < today.toString() }
            val completionPercent = if (finished.isEmpty()) "—" else "${finished.count { it.metrics.perfect } * 100 / finished.size}%"
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Kpi("◎", completionPercent, "Goal completion", Modifier.weight(1f))
                Kpi("✓", "$perfectDays", "Perfect days", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            SectionCard(Modifier.fillMaxWidth()) {
                Text("Daily overall progress (last 7 days)", fontWeight=FontWeight.Bold)
                DailyProgressBars(selectedDays.takeLast(7))
            }
            Spacer(Modifier.height(12.dp))
            SectionCard(Modifier.fillMaxWidth()) {
                Text("Habit completion", fontWeight=FontWeight.Bold)
                listOf("Water","Push-ups","Creatine","Protein shake").forEach { habit ->
                    val eligible= selectedDays.filter { habit=="Water" || habit=="Push-ups" ||
                        (habit=="Creatine"&&it.snapshot.creatineRequired) || (habit=="Protein shake"&&it.snapshot.proteinRequired) }
                    val completed=eligible.count { d -> when(habit){
                        "Water"->d.metrics.waterMet;"Push-ups"->d.metrics.pushUpsMet
                        "Creatine"->d.snapshot.creatineDone;else->d.snapshot.proteinDone } }
                    Text("$habit: ${if(eligible.isEmpty()) "N/A" else "${completed*100/eligible.size}%"}")
                }
            }
            TextButton(onClick={history=true}) { Text("View history calendar → (date list starter)") }
            // Gemini: replace basic list with approved calendar + achievements and accurate elapsed-day completion.
        } else {
            val water=selected=="Water"
            val values=selectedDays.map { if (water) it.totalWater else it.totalReps }
            val avg=if(values.isNotEmpty()) values.average().toInt() else 0
            val record = selectedDays.maxByOrNull { if(water) it.totalWater else it.totalReps }
            val meets=selectedDays.count { if(water) it.metrics.waterMet else it.metrics.pushUpsMet }
            val color=if(water) HydraColors.Aqua else HydraColors.Lime
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Kpi(if(water) "💧" else "↗", "$avg", "Avg ${if(water) "ml" else "reps"}", Modifier.weight(1f))
                Kpi("🏆", "${if(record==null) 0 else if(water) record.totalWater else record.totalReps}", "Best day", Modifier.weight(1f))
                Kpi("✓", "$meets/${selectedDays.size}", "Goal days", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            SectionCard(Modifier.fillMaxWidth()) {
                Text(if(water) "Daily Intake" else "Daily Reps", fontWeight=FontWeight.Bold)
                Text("Current period · actual totals", color=HydraColors.Muted, fontSize=12.sp)
                BarRows(selectedDays.takeLast(30), water, color)
            }
            Spacer(Modifier.height(12.dp))
            SectionCard(Modifier.fillMaxWidth()) {
                Text("Record", fontWeight=FontWeight.Bold)
                Text(record?.let { "${it.snapshot.day} · ${if (water) it.totalWater.toString()+" ml" else it.totalReps.toString()+" reps"}" } ?: "No records")
                Text("Full best-week, hit-streak & historical goal overlays to be implemented in Gemini phase P3.", fontSize=12.sp,color=HydraColors.Muted)
            }
            TextButton(onClick={history=true}) { Text("View history →") }
        }
    }
}

@Composable
private fun Kpi(symbol: String, number:String, label:String, modifier:Modifier) {
    SectionCard(modifier) {
        Text(symbol, fontSize=21.sp)
        Text(number, fontSize=24.sp, fontWeight=FontWeight.ExtraBold)
        Text(label, fontSize=11.sp, color=HydraColors.Muted)
    }
}

@Composable
private fun BarRows(days: List<DayView>, water: Boolean, color: Color=HydraColors.Aqua) {
    if(days.isEmpty()) { Text("No tracked days yet", color=HydraColors.Muted);return }
    days.forEach { d ->
        val amount=if(water) d.totalWater else d.totalReps
        val goal=if(water) d.snapshot.waterGoalMl else d.snapshot.pushUpGoalReps
        Row(Modifier.fillMaxWidth().padding(top=10.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(d.snapshot.day.takeLast(5), fontSize=11.sp, modifier=Modifier.width(46.dp))
            LinearProgressIndicator(progress={ (amount.toFloat()/goal).coerceIn(0f,1f) },
                color=color, modifier=Modifier.weight(1f).height(12.dp), trackColor=Color(0xFFE8F1F1))
            Spacer(Modifier.width(8.dp))
            Text("$amount",fontSize=11.sp,modifier=Modifier.width(42.dp))
        }
    }
}

@Composable
private fun DailyProgressBars(days: List<DayView>) {
    if (days.isEmpty()) { Text("No tracked days yet", color=HydraColors.Muted); return }
    days.forEach { d ->
        val score = d.metrics.progress
        Row(Modifier.fillMaxWidth().padding(top=10.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(d.snapshot.day.takeLast(5), fontSize=11.sp, modifier=Modifier.width(46.dp))
            LinearProgressIndicator(progress={score}, color=HydraColors.Aqua,
                modifier=Modifier.weight(1f).height(12.dp), trackColor=Color(0xFFE8F1F1))
            Spacer(Modifier.width(8.dp))
            Text("${(score*100).toInt()}%", fontSize=11.sp, modifier=Modifier.width(42.dp))
        }
    }
}
