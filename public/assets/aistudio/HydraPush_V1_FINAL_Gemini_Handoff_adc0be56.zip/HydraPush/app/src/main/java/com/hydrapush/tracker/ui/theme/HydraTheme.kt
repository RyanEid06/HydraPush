package com.hydrapush.tracker.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object HydraColors {
    val Aqua = Color(0xFF08C6BF)
    val Lime = Color(0xFF8BD614)
    val Coral = Color(0xFFFB7659)
    val Sky = Color(0xFF46B5EF)
    val Navy = Color(0xFF17373B)
    val Muted = Color(0xFF61727B)
    val Mist = Color(0xFFF5FCFD)
    val TealCard = Color(0xFFE7FAF8)
    val GreenCard = Color(0xFFF1FAE5)
    val RedCard = Color(0xFFFFF0EB)
}

private val HydraLight = lightColorScheme(
    primary = HydraColors.Aqua,
    secondary = HydraColors.Lime,
    background = HydraColors.Mist,
    surface = Color.White,
    onBackground = HydraColors.Navy,
    onSurface = HydraColors.Navy,
    onPrimary = HydraColors.Navy
)

/** V1 starter uses the approved LIGHT design. If a theme picker is introduced,
 * it must really implement the selected mode, not just display a fake row. */
@Composable
fun HydraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = HydraLight, content = content)
}
