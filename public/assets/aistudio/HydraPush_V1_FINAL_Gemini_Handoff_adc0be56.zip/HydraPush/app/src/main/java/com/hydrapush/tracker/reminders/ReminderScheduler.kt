package com.hydrapush.tracker.reminders

/**
 * TODO(P4): Notification channels, runtime POST_NOTIFICATIONS permission,
 * per-habit schedules, disabled-habit cancellation, BOOT_COMPLETED and
 * timezone adjustments. WorkManager for deferrable jobs; exact alarms only
 * if absolutely necessary and justified.
 */
internal object ReminderSchedulerContract
