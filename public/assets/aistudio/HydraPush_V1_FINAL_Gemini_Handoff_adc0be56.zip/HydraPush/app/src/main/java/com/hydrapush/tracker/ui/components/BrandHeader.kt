package com.hydrapush.tracker.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hydrapush.tracker.ui.theme.HydraColors

@Composable
fun BrandHeader(subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
        Row {
            Text("◉ ", color = HydraColors.Aqua, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Hydra", color = HydraColors.Navy, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("Push", color = HydraColors.Aqua, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Text(subtitle, color = HydraColors.Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier, shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(14.dp), content = content)
    }
}
