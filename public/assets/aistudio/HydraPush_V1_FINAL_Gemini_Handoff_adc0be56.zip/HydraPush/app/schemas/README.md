# Room migration snapshots

When Room is implemented, ensure `exportSchema = true`; configure KSP output to this directory and commit generated JSON files with each schema bump. The initial scaffold has no compiled schema JSON yet. Never invent migration snapshots.
