# GEMINI / GOOGLE AI STUDIO — MASTER IMPLEMENTATION PROMPT

You are implementing **HydraPush V1**, a native Kotlin Android app using Jetpack Compose. You receive an Android starter repository and 3 approved reference mockups (Dashboard, Stats triptych, Settings), plus separate stats crops. **Build the actual app from these files**. Do not treat image pixels as UI components. Preserve the app's identity, user data, and existing documents.

## Unbreakable constraints

1. Native Android **Kotlin + Jetpack Compose**, installable APK. NOT React, React Native, web, PWA, Flutter, Capacitor, or a mock frontend.
2. **Fully usable offline.** No INTERNET permission; no account, telemetry, ads, online dependencies at runtime. Gradle may fetch dependencies during build.
3. **Stable `applicationId = com.hydrapush.tracker`**, V1 `versionCode=1`, `versionName=1.0.0`. Subsequent releases increment versionCode and retain package + signing certificate.
4. **No data loss across upgrades**: Room schema migrations, no destructive migration fallback, no database wipe, no applicationId change, release signing kept outside Git; backup import/export with validation and atomic restoration.
5. Local-day behavior and historical immutability defined in `docs/DATA_MODEL.md`. **Water and push-ups always required**; creatine/protein independently optional. Changing optional habits must not rewrite past day snapshots/streak results. No changing yesterday or earlier, including through widget/notifications.
6. **Images are style references**. Respect layouts, light and sporty palette, distinctive aqua water/green pushups/coral protein, 3-item bottom nav. No fake hardcoded stats, no dummy progress, no fake buttons; all controls functional or omitted until implemented.
7. Ask no redundant design questions. Make safe design decisions and log them in docs if needed. Build progressively, testing every phase.

## Source material and hierarchy

Read in order: `docs/DECISIONS.md`, `docs/PRODUCT_SPEC.md`, `docs/BEHAVIOR_RULES.md`, `docs/UI_SPEC.md`, `docs/DATA_MODEL.md`, `docs/ARCHITECTURE.md`, `docs/ACCEPTANCE_TESTS.md`, `docs/RELEASE_SAFETY.md`, `design/tokens.json`, then every file in `V1-Design/`.

**Approved designs:**
- `V1-Design/HydraPush Dashboard.png`: Dashboard layout, two side-by-side dominant cards, bottom nav.
- `V1-Design/HydraPush Stats Dashboard Trio.png`: three Stats states (Overview, Water, Push-ups).
- `V1-Design/HydraPush Settings Dashboard.png`: minimal Settings groups.
- `V1-Design/Stats Overview.png`, `Stats Water.png`, `Stats Push Ups.png`: exact extracted sections from triptych for easier per-screen reference.

## Scope by screen

### Dashboard
- Top logo + energetic running figure, Today date, two equal-priority side-by-side cards.
- Water card: consumed ml / adjustable target, progress ring, +150 / +250 / +500 buttons, custom numeric ml bottom sheet, undo today entry.
- Push-up card: total reps / adjustable target, progress bar and today's ordered set chips/list, `Add Set` sheet asking integer repetitions, undo/delete today's set.
- Smaller creatine/protein cards: one check/uncheck each per day, but **only appear when enabled**.
- One combined **perfect-day** streak; compact daily overall progress. Layout reflows cleanly with 0/1/2 optional cards and at 360dp screen width / larger text.
- Every interaction persists immediately and refreshes stats and widget; no duplicate actions after fast double taps.

### Stats
- Header, 7D/30D/90D/All range pills; tabs **Overview / Water / Push-ups** under header. Selected tab persists in composition.
- Overview: current streak, longest streak, goal completion rate, perfect days, weekly consistency bars, habit completion ring/indicators for enabled currently/selected range with historically required denominators, achievements, **History/calendar access**.
- Overview **must not** contain separate large Water Average or Push-up Average cards.
- Water tab: range average in ml, best single day incl. date, goal-hit days, daily bar chart with goal target line (historical daily goal), weekly consistency percentage, goal hit streak, best consecutive week and record detail. Use only saved records, no fake numbers.
- Push-ups tab: same with reps + daily set analytics; highest reps day and most consistent week; historical goal line. Handle goal changes.
- Stats History inside Stats (segmented subview or entry): calendar shows past days read-only, complete/incomplete state, activity summaries; today may link Dashboard; months navigable.
- Stats range metrics never confuse percent of goal with percent of days; label denominators. Show zeros and empty states honestly. Allow horizontal chart scrolling for 90D/All rather than squashing bars.

### Settings
- Preserve approved minimal grouped-card look: Daily Goals, Reminders, Appearance, Data, About.
- Add a small **Active Habits** group between Daily Goals and Reminders: Water & Push-ups permanently On with lock indication; Creatine and Protein shake independently togglable.
- Adjustable positive water and push-up goals; saved immediately; today snapshot updates, **past snapshots never change**.
- Four independent custom reminder settings; optional habit reminders automatically stop while disabled, resume only if enabled. Android 13+ notification permission with explanation; handle denied permission, reboot, and timezone changes. Avoid unbounded / exact alarms when inexact is acceptable.
- Light-first design with **Follow System** as originally chosen; light is mandatory pixel-accurate design, a restrained dark variant may be added. Do not force dark UI or delay light V1 to polish dark.
- Data: export/import manual offline backup using Android Storage Access Framework, integrity/version validation, user warning before overwrite, atomic transaction, clear success/error feedback. About shows actual version.

### Widget + achievements
- Glance (or well-supported RemoteViews) real Android home-screen widget, responsive small and medium sizes: progress/quick water + push-up logging, creatine/protein toggles only when enabled, and open-app action. If widget space is too small, use click-to-open instead of deceptive nonfunctional mini buttons. Update after logs/day rollover/settings/import.
- Moderate badges: first perfect day, 3/7/30-day perfect streak, 2L water day, 100-rep day, 1,000 lifetime reps, 7 creatine/protein completions (only when relevant). Celebrate nonintrusively, no spam.

## Architecture and persistence

Keep UI -> ViewModel/Repository -> Room/DataStore (one source of truth). Do not store health log only in `remember`/in-memory state. Use fixed, explicit schemas for `DailySnapshot`, `WaterEntry`, `PushUpSet`, `ConfigurationRevision`, `Achievement`; historical snapshots freeze goal + required habits. Use `java.time.LocalDate` and `ZoneId.systemDefault` with defined timezone handling; dates in ISO YYYY-MM-DD; entry timestamps as epoch ms. Implement idempotent day rollover/backfill for missing days and app reopens. Settings changes apply today forward. Reject updates for past days in repository and widget receiver, not just in UI. Calculate scores from snapshots (see `docs/BEHAVIOR_RULES.md`).

## Execution order (each checkpoint must pass)

1. **Project/build audit**: inspect entire ZIP; pin compatible stable Gradle, AGP, Kotlin, Compose BOM, Room, DataStore, WorkManager, Glance and KSP. Include official wrapper JAR (the initial scaffold may omit it); configure Android SDK; run `:app:assembleDebug`, unit tests. Fix build before writing features.
2. **Data correctness**: implement Room entities/DAO/repository, settings persistence, snapshot/version model, logging, today undo, day rollover, immutable history, unit/instrumented tests.
3. **UI Dashboard**: match screenshot faithfully using true Compose cards/pills/rings; connect all actions, check screen sizes and accessibility.
4. **Stats + History**: full Overview/Water/Push-ups tabs, charts, calendars, honest statistics, consistency and records.
5. **Settings + active habits**: configure goals, reminders, optional status semantics, dark/light support as described, backups.
6. **Widget + reminders + achievements**: event-driven updates, Android permission/reboot/notification channels, badges.
7. **Release QA**: 100% acceptance tests, no internet permission, no crashes, no lost data after kill/upgrade/restore. Build signed APK with locally generated and securely stored keystore; document signing, checksum, version code and install instructions. Do NOT place private keystore/passwords in repository.

## Delivery format

Return a completed project folder/repository + installable debug APK and, only after user provides/creates secure keystore, signed release APK. Provide a factual checklist with ✅ only for tests actually executed, evidence of builds, remaining gaps, and how to install/upgrade without losing history. Do not claim screenshots are working UI. Never claim QA done without running it. Do not replace the existing designs or delete docs without explicit permission.
