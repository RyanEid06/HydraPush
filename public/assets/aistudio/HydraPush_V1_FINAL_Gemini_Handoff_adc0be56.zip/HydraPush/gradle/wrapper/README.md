# Gradle wrapper bootstrap

`gradle-wrapper.properties` is prepared for Gradle **9.4.1**. The official `gradle-wrapper.jar` and launcher scripts **are not included**: downloads were unavailable in the authoring sandbox. **Do not assume this is directly CLI buildable until wrapper is generated.**

Gemini / developer: install a trusted Gradle distribution or open project in Android Studio and run `gradle wrapper --gradle-version 9.4.1` from project root. Confirm the generated official scripts and JAR, then commit them. Do not download an unverified wrapper from a random site. Fix dependency compatibility as part of the first build; docs are authoritative on app behavior, not dependency versions.
