# QA operator checklist

Use `docs/ACCEPTANCE_TESTS.md` as the actual test contract. Create separate test data on an emulator, not the owner's real private data. Install debug starter only for development, and establish a *release-signed* version on the real phone to support future in-place upgrades.

Suggested emulator scenarios: fresh install, 360dp compact phone, 1.3x font scale, landscape not necessary but no crash; airplane mode; notification denied; force-stop; midnight by emulator clock; optional habits disabled; goal changed; backup import from second device; upgrade on same appId+signature.
