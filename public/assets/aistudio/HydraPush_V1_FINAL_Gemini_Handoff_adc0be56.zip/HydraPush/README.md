# HydraPush — Android V1 handoff package

**Status: prepared scaffold + approved design references, NOT a finished application or verified APK.**

HydraPush is a native, offline-only Android habit tracker for water, push-up sets, and optional creatine/protein-shake check-ins. The three original design images are preserved in `V1-Design/`; the stats triptych is additionally split into three easy-to-reference crops.

## First thing for Gemini / Google AI Studio

1. Open **`GEMINI_START_HERE.md`** and follow/paste its complete instructions.
2. Supply the entire unzipped project and all `V1-Design` images as reference files. **Do not generate a React/web/PWA substitute**; deliver a native Android APK.
3. Read `docs/DECISIONS.md`, `docs/PRODUCT_SPEC.md`, `docs/UI_SPEC.md`, `docs/DATA_MODEL.md`, `docs/ACCEPTANCE_TESTS.md`, and `docs/RELEASE_SAFETY.md` before editing source.
4. Continue the included Kotlin/Compose skeleton; complete the real Room/backup/reminder/widget functionality. Treat mockups as visual references, **not screenshots to display in the app**.
5. Run debug build, unit tests, instrumented UI tests, install on emulator/phone, test persistent data across app exit and app update; only then deliver a signed installable APK.

## What already exists

- Android project files, source directories and basic navigation/theme/starter screens.
- Original approved design reference PNGs; separated stats PNGs.
- Complete feature rules, data definitions, screen/UI specification, design tokens.
- See `docs/CURRENT_IMPLEMENTATION_STATUS.md` to distinguish implemented starters from unfinished features.
- Implementation phases, test checklist, release and backup safeguards, initial domain tests, CI file.

## What Gemini still MUST implement/verify

- Full Room persistence, day snapshots and immutable history, all logging interactions and analytics.
- Settings persistence; optional supplement activation/deactivation with correct streak/reminder behavior.
- Backup/export/import with integrity checks; actual notifications and full home-screen widget.
- Refined layouts matching images; accessibility, animations, day-boundary/restore tests.
- A clean, verified working build with Gradle wrapper and signing process.

**The skeleton is intentionally not presented as a finished V1.** Build cannot be verified in the file-generation environment because no Android SDK or Gradle distribution is installed there. Gemini must perform that verification.

## Project map

- `app/` — native Android module.
- `docs/` — authoritative functional/technical contracts.
- `V1-Design/` — reference mockups (originals unchanged).
- `design/tokens.json` — visual reference palette and component values.
- `.github/workflows/` — Android CI template.
- `scripts/` — bootstrap/validation and release guidance.

## Local build (after Gemini completes implementation)

Open in **Android Studio** with JDK 17+, Android SDK 37 and Build Tools. Generate/download official Gradle Wrapper 9.4.1 if missing (`gradle wrapper --gradle-version 9.4.1` using a local Gradle installation). Run `./gradlew :app:assembleDebug :app:testDebugUnitTest` on Linux/macOS or `gradlew.bat` on Windows. Never use an unknown online wrapper binary.

Package name / update identity: `com.hydrapush.tracker`. Preserve this package and the same release signing key for every future upgrade. Do not include a private signing key in this ZIP or in Git.
